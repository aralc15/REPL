#ifndef interprete_h
#define interprete_h

void interpret (const char *source) ;
void iniciar();

#endif